﻿using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace CustomRandomList
{
    using System;
    using System.Linq;
    public class RandomList : List<string>
    {
  
        public void RandomString()
        {
            Random random = new Random();
            int randomNumber = random.Next(0, this.Count);
            RemoveAt(randomNumber);

        }
    }
}
